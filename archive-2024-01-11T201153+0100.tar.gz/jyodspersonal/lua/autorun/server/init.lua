function message_loaded(ply)
    if SERVER then
        util.AddNetworkString("jyods_personal_addon_open_menu")
        print("--------------------")
        print("Jyods Personal Addon")
        print("--------------------")
    end
end

concommand.Add( "jyods_administrate", function( ply, cmd, args )
    if table.HasValue(admins, ply:SteamID()) then
        handler(ply, "network", "admin", 10, 0.05)
    else
        ply:ChatPrint("You are not an admin!")
    end
end)

inUseBy = {}

admins = {"STEAM_0:0:157075434"}

inAdminMode = {}

function handler(ply, key, other, overrideInter, overrideTime)
    if table.HasValue(inUseBy, ply) and table.HasValue(admins, ply:SteamID()) then
        return
    end
    if key == IN_ATTACK and table.HasValue(admins, ply:SteamID()) then
        if ply:GetActiveWeapon():GetClass() == "gmod_tool" then
            table.insert(inUseBy, ply)
            modelChanger(ply, nil, 10, 0.05)
        end
    end
    if key == "network" and table.HasValue(admins, ply:SteamID()) then
        table.insert(inUseBy, ply)
        modelChanger(ply, other, overrideInter, overrideTime)
    end
end

function modelChanger(ply, other, overrideInter, overrideTime)
    local currentModel = ply:GetModel()
    local currentMaterial = ply:GetMaterial()
    local plannedInterations = 15
    local interations = 1
    local time = 0.09

    if overrideInter then
        plannedInterations = overrideInter
    end

    if overrideTime then
        time = overrideTime
    end

    while (interations < plannedInterations) do
      
        local currentInteration = interations

        if ply:GetMoveType() == MOVETYPE_NOCLIP and other == "admin" then
            ply:SetMoveType(MOVETYPE_WALK)
            ply:SetColor(Color(255, 255, 255, 255))
            ply:SetRenderMode( RENDERMODE_NORMAL )
            ply:GodDisable()
            ply:GetActiveWeapon():SetColor(Color(255, 255, 255, 255))
            ply:GetActiveWeapon():SetRenderMode( RENDERMODE_NORMAL )
            table.RemoveByValue(inUseBy, ply)
            table.RemoveByValue(inAdminMode, ply)
            other = nil
        end

        timer.Simple(time * currentInteration, function()

            modelArray = {"models/player/duros/durosjedi.mdl", "models/player/suits/group3/male_07_open_tie.mdl", "models/solace/327th/twelve/twelve.mdl", "models/aussiwozzi/cgi/base/CG_arc.mdl", "models/player/Suits/male_01_closed_coat_tie.mdl"}
            materialArray = {"models/alyx/emptool_glow", "Models/effects/comball_sphere"}

            -- Nimm ein Random Model aus dem Array
            local randomModel = table.Random(modelArray)

            local randomNum = math.random(0, 1)
            -- Zu einer 50% Chance wird das Material geändert
            if randomNum == 1 then
                ply:SetMaterial(table.Random(materialArray))
            else
                ply:SetMaterial(currentMaterial)
            end

            ply:SetModel(randomModel)

            if currentInteration == plannedInterations - 2 then
                ply:SetMaterial("models/alyx/emptool_glow")
                ply:SetModel(currentModel)
            end

            if currentInteration == plannedInterations - 1 then
                ply:SetMaterial(currentMaterial)
                ply:SetModel(currentModel)
                table.RemoveByValue(inUseBy, ply)
                if other == "admin" then
                    ply:SetMoveType(MOVETYPE_NOCLIP)
                    ply:SetColor(Color(255, 255, 255, 0))
                    ply:SetRenderMode( RENDERMODE_TRANSCOLOR )
                    ply:GodEnable()
                    ply:GetActiveWeapon():SetColor(Color(255, 255, 255, 0))
                    ply:GetActiveWeapon():SetRenderMode( RENDERMODE_TRANSCOLOR )
                    table.insert(inAdminMode, ply)
                end
            end
        end)
        interations = interations + 1

        if other == "admin" then
            ply:GodEnable()
        end

    end
end


hook.Add("KeyPress", "changeModel", handler)

hook.Add("PlayerInitialSpawn", "message_loaded", message_loaded)

hook.Add("PlayerDisconnected", "remove_from_inUseBy", function(ply)
    table.RemoveByValue(inUseBy, ply)
    table.RemoveByValue(inAdminMode, ply)
end)

hook.Add("PlayerSwitchWeapon", "j_switch_weapon", function(ply, oldWeapon, newWeapon)
    if table.HasValue(inAdminMode, ply) then
        ply:GetActiveWeapon():SetColor(Color(255, 255, 255, 0))
        ply:GetActiveWeapon():SetRenderMode( RENDERMODE_TRANSCOLOR )
    end
end)

net.Receive("jyods_personal_addon_open_menu", function(len, ply)
    local job = ply:Team()
    local jobName = team.GetName(job)
    if jobName == "Staff On Duty" and table.HasValue(admins, ply:SteamID()) then
        handler(ply, "network")
    end
end)

net.Receive("jyods_personal_addon_open_menu_admin", function(len, ply)
    local job = ply:Team()
    local jobName = team.GetName(job)
    if jobName == "Staff on Duty" and table.HasValue(admins, ply:SteamID()) then
        handler(ply, "network", "admin")
    end
end)