if CLIENT then
    function openMenu()
        local ply = LocalPlayer()
        if ply:SteamID() == "STEAM_0:0:157075434" then
            net.Start("jyods_personal_addon_open_menu")
            net.SendToServer()
        end
    end

    hook.Add("OnContextMenuOpen", "openMenu", openMenu)
    hook.Add("OnSpawnMenuOpen", "openMenu", openMenu)
end