ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Strafregister Opener"

ENT.Category = "Project Genesis"

ENT.Spawnable = true

ENT.AdminOnly = false


if SERVER then
    util.AddNetworkString("OpenWebPage")
end