include("shared.lua")

function ENT:Draw()
   
    self:DrawModel()

end

local open = false

net.Receive("OpenWebPage", function()

    if open then return end
    open = true

    local websiteURL = "https://home-5013261951.app-ionos.space"
    local webFrame = vgui.Create("DFrame")
    webFrame:SetSize(800, 600)
    webFrame:SetTitle("Web Page")
    webFrame:Center()
    webFrame:MakePopup()

    local webView = vgui.Create("DHTML", webFrame)
    webView:Dock(FILL)
    webView:OpenURL(websiteURL)

    webFrame.OnClose = function()
        open = false
        webFrame = nil
    end
end)