include("shared.lua")

function ENT:Draw()
   
    self:DrawModel()

end

local open = false

net.Receive("AskScanner", function()
    if open then return end
    open = true
    --Der User soll ein Fenter bekomme wo er auf einen Knopf drücken kann, die Antwort wird an den Server gesendet
    local frame = vgui.Create("DFrame")
    frame:SetSize(300, 500)
    frame:Center()
    frame:SetTitle("Scanner")
    frame:MakePopup()

    local button = vgui.Create("DButton", frame)
    button:SetText("Local Scan")
    button:SetPos(100, 100)
    button:SetSize(100, 30)
    button.DoClick = function()
        net.Start("StartScan")
        net.WriteEntity(LocalPlayer())
        net.WriteString("Local")
        net.SendToServer()
        frame:Close()
    end

    local button2 = vgui.Create("DButton", frame)
    button2:SetText("Sector Scan")
    button2:SetPos(100, 150)
    button2:SetSize(100, 30)
    button2.DoClick = function()
        net.Start("StartScan")
        net.WriteEntity(LocalPlayer())
        net.WriteString("Sector")
        net.SendToServer()
        frame:Close()
    end

    local button3 = vgui.Create("DButton", frame)
    button3:SetText("Planet Scan")
    button3:SetPos(100, 200)
    button3:SetSize(100, 30)
    button3.DoClick = function()
        net.Start("StartScan")
        net.WriteEntity(LocalPlayer())
        net.WriteString("Planet")
        net.SendToServer()
        frame:Close()
    end

    local buttonclose = vgui.Create("DButton", frame)
    buttonclose:SetText("Close")
    buttonclose:SetPos(100, 300)
    buttonclose:SetSize(100, 30)

    buttonclose.DoClick = function()
        frame:Close()
    end

    frame.OnClose = function()
        frame = nil
        open = false
    end

end)