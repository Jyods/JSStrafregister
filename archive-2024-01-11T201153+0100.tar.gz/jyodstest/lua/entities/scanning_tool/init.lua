AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

local countdownActive = false
local prefix = "<c=255,0,255>[System]</c> "

function ENT:Initialize()

    self:SetModel("models/hunter/plates/plate05x05.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:SetColor(Color(0, 0, 0, 0))
    self:SetRenderMode(RENDERMODE_TRANSALPHA)

    local phys = self:GetPhysicsObject()

    if phys:IsValid() then
        phys:Wake()
    end

end

function ENT:Use(activator, caller)
    if IsValid(caller) and caller:IsPlayer() and SERVER then
        net.Start("AskScanner")
        net.Send(caller)
    end
end

function countdownFunction(type, time, ply)

    if countdownActive then
        ply:ChatPrint(prefix .. "Es läuft bereits ein Scan. Bitte warte, bis er abgeschlossen ist.")
        return
    end

    PrintMessage(HUD_PRINTTALK, prefix .. ply:Nick() .. " hat einen " .. type .. " gestartet" )

    countdownActive = true

    timer.Create("Countdown", 1, time + 1, function()
            
        if timer.RepsLeft("Countdown") == 0 then
            PrintMessage(HUD_PRINTTALK, prefix .. type .. " beendet!")
            countdownActive = false
        else
            if timer.RepsLeft("Countdown") % 10 == 0 || timer.RepsLeft("Countdown") < 10 then
                    if timer.RepsLeft("Countdown") % 5 == 0 || timer.RepsLeft("Countdown") < 5 then
                PrintMessage(HUD_PRINTTALK, prefix .. type .." in Bearbeitung... " .. timer.RepsLeft("Countdown") .. " seconds verbleibend.")
                        end
            end
        end

    end)

end

if SERVER then
    net.Receive("StartScan", function(len, ply)
        net.ReadEntity()
        local mode = net.ReadString()

        if mode == "Local" then
            countdownFunction("Lokaler Scan", 10, ply)
            -- local ents = ents.FindInSphere(ply:GetPos(), 100)
            -- for k, v in pairs(ents) do
            --     if v:GetClass() == "npc_citizen" then
            --         PrintMessage(HUD_PRINTTALK, "NPC gefunden")
            --     end
            -- end
        elseif mode == "Sector" then
            countdownFunction("Sektoren Scan", 20, ply)
        elseif mode == "Planet" then
            countdownFunction("Planeten Scan", 30, ply)
        end

    end)
end