AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

local countdownActive = false
local prefix = "[System] "

function ENT:Initialize()

    self:SetModel("models/hunter/plates/plate05x05.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:SetColor(Color(0, 0, 0, 0))
    self:SetRenderMode(RENDERMODE_TRANSALPHA)

    local phys = self:GetPhysicsObject()

    if phys:IsValid() then
        phys:Wake()
    end

end

function getRadiosTable()
    local radios = nil
    if sql.TableExists("jfunksystem") then
    radios = sql.Query("SELECT * FROM jfunksystem")
    else
        return false
    end
    return radios
end	

    

function ENT:Use(activator, caller)
    if IsValid(caller) and caller:IsPlayer() and SERVER then
        local radios = getRadiosTable()
        if radios == false then
            caller:ChatPrint(prefix .. "No radios found!")
            return
        end
        net.Start("ShowRadios")
        net.WriteTable(radios)
        net.Send(caller)
    end
end
