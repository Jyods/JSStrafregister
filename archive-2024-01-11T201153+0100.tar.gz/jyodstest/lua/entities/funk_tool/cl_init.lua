include("shared.lua")

function ENT:Draw()
   
    self:DrawModel()

end

local open = false

net.Receive("ShowRadios", function()
    if open then return end
    open = true
    local theRadios = net.ReadTable()

    -- kehre die Tabelle um, damit die neusten Funksprüche oben sind
    local reversed = {}
    for i = #theRadios, 1, -1 do
        table.insert(reversed, theRadios[i])
    end
    theRadios = reversed

    --Erstelle ein GUI und zeige alle Funksprüche an, sortiere anhand der Methode, es gibt Felder: (id NUMBER , fromName TEXT , fromSteamID TEXT , toName TEXT , message TEXT , methode TEXT) Stelle sicher, dass nicht allzuviel padding ist
    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW() * 0.5, ScrH() * 0.5)
    frame:Center()
    frame:SetTitle("Funksprüche")
    frame:MakePopup()

    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)

    local sbar = scroll:GetVBar()
    function sbar:Paint(w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 0))
    end
    function sbar.btnUp:Paint(w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 0))
    end
    function sbar.btnDown:Paint(w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 0))
    end
    function sbar.btnGrip:Paint(w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 0))
    end

    local list = vgui.Create("DIconLayout", scroll)
    list:Dock(FILL)
    list:SetSpaceY(5)

    for k, v in pairs(theRadios) do
        local panel = list:Add("DPanel")
        panel:SetSize(ScrW() * 0.5, ScrH() * 0.2)
        panel:Dock(TOP)
        panel:DockMargin(0, 0, 0, 5)
        panel.Paint = function(self, w, h)
            draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 150))
        end

        local fromName = vgui.Create("DLabel", panel)
        fromName:SetPos(5, 5)
        fromName:SetSize(ScrW() * 0.5, ScrH() * 0.1)
        fromName:SetText("Von: " .. v.fromName)
        fromName:SetFont("Trebuchet24")
        fromName:SetColor(Color(255, 255, 255))

        local toName = vgui.Create("DLabel", panel)
        toName:SetPos(5, 30)
        toName:SetSize(ScrW() * 0.5, ScrH() * 0.1)
        toName:SetText("An: " .. v.toName)
        toName:SetFont("Trebuchet24")
        toName:SetColor(Color(255, 255, 255))

        local message = vgui.Create("DLabel", panel)
        message:SetPos(5, 55)
        message:SetSize(ScrW() * 0.5, ScrH() * 0.1)
        message:SetText("Nachricht: " .. v.message)
        message:SetFont("Trebuchet24")
        message:SetColor(Color(255, 255, 255))

        local methode = vgui.Create("DLabel", panel)
        methode:SetPos(5, 80)
        methode:SetSize(ScrW() * 0.5, ScrH() * 0.1)
        methode:SetText("Methode: " .. v.methode)
        methode:SetFont("Trebuchet24")
        methode:SetColor(Color(255, 255, 255))

        local time = vgui.Create("DLabel", panel)
        time:SetPos(5, 105)
        time:SetSize(ScrW() * 0.5, ScrH() * 0.1)
        time:SetText("Zeit: " .. v.time)
        time:SetFont("Trebuchet24")
        time:SetColor(Color(255, 255, 255))
    end

    local close = vgui.Create("DButton", frame)
    close:SetSize(ScrW() * 0.1, ScrH() * 0.05)
    close:SetPos(ScrW() * 0.4, ScrH() * 0.45)
    close:SetText("Schließen")
    close:SetFont("Trebuchet24")
    close:SetColor(Color(255, 255, 255))
    close.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0))
    end
    close.DoClick = function()
        frame:Close()
        open = false
    end

end)