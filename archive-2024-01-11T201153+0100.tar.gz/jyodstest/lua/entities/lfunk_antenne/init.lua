AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()

    self:SetModel("models/hunter/plates/plate05x05.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:SetColor(Color(0, 0, 0, 0))
    self:SetRenderMode(RENDERMODE_TRANSALPHA)

    local phys = self:GetPhysicsObject()

    if phys:IsValid() then
        phys:Wake()
    end

end

local isOn = false

function ENT:Use(activator, caller)
    if IsValid(caller) and caller:IsPlayer() and SERVER then
        if isOn then
            isOn = false
            self:SetColor(Color(0, 0, 0, 0))
            self:SetRenderMode(RENDERMODE_TRANSALPHA)
            self:SetCollisionGroup(COLLISION_GROUP_WORLD)
        else
            isOn = true
            self:SetColor(Color(0, 0, 0, 0))
            self:SetRenderMode(RENDERMODE_TRANSALPHA)
            self:SetCollisionGroup(COLLISION_GROUP_NONE)
        end
    end
end

function ENT:Think()
    if isOn then
        local effectdata = EffectData()
        effectdata:SetOrigin(self:GetPos())
        effectdata:SetMagnitude(1)
        effectdata:SetScale(1)
        effectdata:SetRadius(1)
        util.Effect("Sparks", effectdata)
    end
end

function ENT:OnTakeDamage(dmg)
    self:TakePhysicsDamage(dmg)
end

function ENT:Touch(ent)
    if ent:GetClass() == "prop_physics" then
        ent:Remove()
    end
end