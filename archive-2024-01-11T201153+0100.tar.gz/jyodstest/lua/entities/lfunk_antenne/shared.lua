ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Langstrecken Antenne"

ENT.Category = "Project Genesis"

ENT.Spawnable = true