-- Definieren der Waffe
SWEP.PrintName = "ID-Scanner"
SWEP.Category = "Project Genesis"
SWEP.Instructions = "Linksklick zum scannen der ID des Spielers vor dir"
SWEP.Author = "Jyods"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.Slot = 5
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic	= false
SWEP.Primary.Ammo		= "none"
SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo		= "none"
SWEP.ViewModel = "models/swcw_items/sw_datapad_v.mdl"
SWEP.WorldModel = "models/swcw_items/sw_datapad.mdl"
SWEP.ViewModelFOV = 70
SWEP.ViewModelFlip = false
SWEP.UseHands = true
SWEP.ShowViewModel = true
SWEP.ShowWorldModel = true
SWEP.ViewModelBoneMods = {
    ["ValveBiped.Bip01_R_Finger01"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger02"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger0"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger1"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger1"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger1"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger1"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    }
}

local using = false
local scanning = false
local frame = nil


function scan(self, player, target)
    
    local distance = self.Owner:GetPos():Distance(target:GetPos())

    if distance > 100 then
        player:ChatPrint("Du bist zu weit weg!")
        target:SetColor(Color(255, 255, 255, 255))
        scanning = false
        return
    end
    
    local username = target:Nick()

    local regex = "[0-9][0-9][0-9][0-9]"

    local id = string.match(username, regex) || "6659"

    if not id then
        player:ChatPrint("Der Spieler hat keine ID!")
        target:SetColor(Color(255, 255, 255, 255))
        scanning = false
        return
    end
    					
    local websiteURL = "https://api.strafregister.jyods.com/public/api/gmod/iswanted/" .. id

    player:ChatPrint("Starte Abfrage..." .. id)

    -- Erstelle eine Anfrage an die URL p^mit GET und wenn die Anfrage erfolgreich war (200) dann schreibe die message
    http.Fetch(websiteURL, function(body, len, headers, code)
        if code == 200 then
            -- Das sollte der body sein, wenn iswanted 1 ist, dann gib dem Spieler eine Nachricht, dass er gesucht wird {"data":{"message":"The Subject is wanted!","identification":"CT-6659","filesCount":1,"isWanted":1}}

            local json = util.JSONToTable(body)

            if json.data.isWanted == 1 then
                player:ChatPrint("<c=255,0,0>Der Spieler ist gesucht!</c>")
            else
                player:ChatPrint("Der Spieler ist <lg>nicht</lg> gesucht!")
            end
        else
            player:ChatPrint("Der Spieler ist nicht in der Strafdatenbank vorhanden.")
        end
    end)

    player:ChatPrint("<c=255,255,0>Abfrage Ergebnis: </c>" .. username)
    target:SetColor(Color(255, 255, 255, 255))
    scanning = false
end

	function scanPlayer(self)
            local player = LocalPlayer()

        	scanning = true

            player:ChatPrint("<hscan c=255,0,0>Scanne Spieler... </hscan>")

            local trace = self.Owner:GetEyeTrace()
            local ent = trace.Entity

            if not IsValid(ent) or not ent:IsPlayer() then
                player:ChatPrint("Kein Spieler gefunden!")
        	 	scanning = false
                return
            end

            -- Change color of entity
        	ent:SetColor(Color(0, 0, 255, 255))

            -- Timer mit 5 Sekunden, die einfach "den spieler scant" und dann die Farbe wieder zurücksetzt
            timer.Simple(5, function()
                scan(self, player, ent)
            end)

            -- TODO: Funktion dass sich das Strafregister mit dem gescannten Spieler öffnet
        end

function SWEP:PrimaryAttack()
    -- Erstelle ein Menü, wenn der Spieler auf die linke Maustaste drückt auf dem er das Scannen des Spielers vor ihm starten kann, anschliessend wird der Name des Spielers in den Chat ausgegeben
    if CLIENT or SERVER then

        if not IsFirstTimePredicted() then return end
        
        --if using then return end

        if scanning == true then return end
        
        scanPlayer(self)

        --using = true
		/*
        --Baue ein Frame auf mit den Buttons Scannen und schliessen
        frame = vgui.Create("DFrame")
        frame:SetSize(300, 100)
        frame:SetPos(ScrW() / 2 - 150, ScrH() / 2 - 50)
        frame:SetTitle("ID-Scanner")
        frame:SetVisible(true)
        frame:SetDraggable(false)
        frame:ShowCloseButton(false)
        frame:MakePopup()

        --Baue einen Button zum Scannen des Spielers vor dem Spieler
        local scanButton = vgui.Create("DButton", frame)
        scanButton:SetText("Scannen")
        scanButton:SetPos(10, 30)
        scanButton:SetSize(100, 60)

        --Baue einen Button zum Schliessen des Menüs
        local closeButton = vgui.Create("DButton", frame)
        closeButton:SetText("Schliessen")
        closeButton:SetPos(190, 30)
        closeButton:SetSize(100, 60)

        --Funktion zum Schliessen des Menüs
        closeButton.DoClick = function()
            frame:Close()
        end

        --Funktion zum Scannen des Spielers vor dem Spieler
        scanButton.DoClick = function()
            local player = LocalPlayer()

        	scanning = true

            player:ChatPrint("Scanne Spieler...")

            local trace = self.Owner:GetEyeTrace()
            local ent = trace.Entity

            if not IsValid(ent) or not ent:IsPlayer() then
                player:ChatPrint("Kein Spieler gefunden!")
                frame:Close()
                return
            end

            -- Change color of entity
        	ent:SetColor(Color(0, 0, 255, 255))

            -- Timer mit 5 Sekunden, die einfach "den spieler scant" und dann die Farbe wieder zurücksetzt
            timer.Simple(5, function()
                scan(self, player, ent)
            end)

            frame:Close()

            -- TODO: Funktion dass sich das Strafregister mit dem gescannten Spieler öffnet
        end
        
        frame.OnClose = function()
            using = false
            frame = nil
        end
        
        */
        
    end

end

