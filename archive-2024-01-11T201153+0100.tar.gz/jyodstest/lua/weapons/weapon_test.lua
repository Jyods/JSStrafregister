-- Definieren der Waffe
SWEP.PrintName = "TEST"
SWEP.Category = "Project Genesis"
SWEP.Instructions = "Linksklick zum Öffnen des Strafregisters"
SWEP.Author = "Jyods"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.Slot = 5
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic	= false
SWEP.Primary.Ammo		= "none"
SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo		= "none"
SWEP.ViewModel = "models/swcw_items/sw_datapad_v.mdl"
SWEP.WorldModel = "models/swcw_items/sw_datapad.mdl"
SWEP.ViewModelFOV = 70
SWEP.ViewModelFlip = false
SWEP.UseHands = true
SWEP.ShowViewModel = true
SWEP.ShowWorldModel = true
SWEP.ViewModelBoneMods = {
    ["ValveBiped.Bip01_R_Finger01"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger02"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger0"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger1"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger1"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger1"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    },
    ["ValveBiped.Bip01_R_Finger1"] = {
        scale = Vector(0.009, 0.009, 0.009),
        pos = Vector(0, 0, 0),
        angle = Angle(0, 0, 0)
    }
}

local currentlyOpen = false
local webFrame = nil

-- Erstellen einer benutzerdefinierten Funktion zum Öffnen der Webseite
function SWEP:PrimaryAttack()
    if CLIENT then
        if currentlyOpen then
            return
        end

        currentlyOpen = true

        local ply = LocalPlayer()
        ply:PrintMessage(HUD_PRINTTALK, "Öffne Webseite...")

        -- Warte 5 Sekunden, bevor currentlyOpen auf false gesetzt wird
        timer.Simple(5, function()
            currentlyOpen = false
        end)

        webFrame = nil
    end
end

function SWEP:SecondaryAttack()
    if CLIENT then
        if not currentlyOpen then
            return
        end

        if webFrame then
            webFrame:Close()
        end
    end
end
