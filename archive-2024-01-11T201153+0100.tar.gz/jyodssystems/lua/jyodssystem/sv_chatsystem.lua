local permittedRanks = {"serverleiter", "superadmin", "teamleitung", "administrator", "headadministrator", "eventmoderator", "eventseniormoderator"}

    -- Erstelle eine Funktion die alle 5 sekunden 10% hinzufügt, bis 100% erreicht sind "[COUNTDOWN] user text [10%]" 
    function countdown(ply, text, plyteam, args)
        local playerRank = ply:GetUserGroup()
        local playerColor = team.GetColor(ply:Team())
        local mid = "<c=" .. playerColor.r .. "," .. playerColor.g .. "," .. playerColor.b .. "> " .. ply:Nick() .. " </c>"
        PrintMessage(HUD_PRINTTALK, "<c=255,102,0>[COUNTDOWN] </c>" .. mid .. " " .. table.concat(args, " ") .. " <c=255,102,0>[0%]</c>")
        timer.Create("countdown", 5, 10, function()
            local percent = 100 - (timer.RepsLeft("countdown") * 10)
            PrintMessage(HUD_PRINTTALK, "<c=255,102,0>[COUNTDOWN] </c>" .. mid .. " " .. table.concat(args, " ") .. " <c=255,102,0>[" .. percent .. "%]</c>")
        end)
        return ""
    end

	function makemessage(plyNick)
        local teamColor = team.GetColor(ply:Team())
        local makePrefix = "<c=" .. teamColor.r .. "," .. teamColor.g .. "," .. teamColor.b .. ">"
    	return makePrefix .. plyNick:Nick() .. "</c>"
    end
    	

function commands(ply, text, plyteam)
    local playerRank = ply:GetUserGroup()
    if string.sub(text, 1, 1) == "/" then
        local args = string.Explode(" ", text)
        local command = string.sub(args[1], 2)
        table.remove(args, 1)
        if command == "akt" then

            local playerColor = team.GetColor(ply:Team())
            local mid = "<c=" .. playerColor.r .. "," .. playerColor.g .. "," .. playerColor.b .. "> " .. ply:Nick() .. " </c>"

            PrintMessage(HUD_PRINTTALK, "<c=255,102,0>[AKT] </c>" .. mid .. " " .. table.concat(args, " "))
            return ""
        elseif command == "eakt" then
            -- Überprüfe ob der Spieler die ulx Gruppe "superadmin", "admin" oder "moderator" hat
            if table.HasValue(permittedRanks, playerRank) then
                PrintMessage(HUD_PRINTTALK, "<c=51,204,204>[EVENTAKT] * * * </c>" .. " " .. table.concat(args, " "))
            else
                ply:ChatPrint("Du hast keine Berechtigung für diesen Befehl!")
            end
            return ""
        elseif command == "id" then
            local playerColor = team.GetColor(ply:Team())
            local mid = "<c=" .. playerColor.r .. "," .. playerColor.g .. "," .. playerColor.b .. ">" .. ply:Nick() .. "</c>"
            local range = 500
            local pos = ply:GetPos()
            for _, v in ipairs(player.GetAll()) do
                if v:GetPos():Distance(pos) < range then
                    v:ChatPrint("<c=255,102,0>[ID] </c>" .. ply:Nick() .. " " .. table.concat(args, " "))
                end
            end
            return ""
        elseif command == "countdown" then
            countdown(ply, text, plyteam, args)
            return ""
        elseif command == "pts" then
            local playerColor = team.GetColor(ply:Team())
            local mid = "<c=" .. playerColor.r .. "," .. playerColor.g .. "," .. playerColor.b .. ">" .. ply:Nick() .. "</c>"
            local range = 500
            local pos = ply:GetPos()
            for _, v in ipairs(player.GetAll()) do
                if v:GetPos():Distance(pos) < range then
                    v:ChatPrint("<c=255,102,0>[PTS] </c>" .. ply:Nick() .. " fordert PTS an.")
                end
            end
            return ""
        elseif command == "looch" then
            ply:ChatPrint("Diesen Befehl gibt es leider nicht @Julius")
            return ""
        elseif command == "roil" then
            ply:ChatPrint("Diesen Befehl gibt es leider nicht @Lucca")
            return ""
        end
    end
end

hook.Add("PlayerSay", "JChatSystem", commands)


hook.Add("PlayerGiveSWEP", "Restriction", function(player, class, weapon)
    local playerRank = player:GetUserGroup()

    if table.HasValue(permittedRanks, playerRank) then
        return true
    else
        --player:ChatPrint("[JRS] You are not allowed to spawn weapons.")
        return false
    end
end)
