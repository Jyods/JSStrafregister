local prefix = "<c=0,255,0>[AED]</c> "

-- Überprüfe ob es einen toten Spieler in der Nähe gibt und gib den ersten spieler zurück den du findest
function getDeadPlayer(ply)
    local players = player.GetAll()
    local deadPlayer = nil

    for k, v in pairs(players) do
        if (v:Alive() == false) then
            deadPlayer = v
            break
        end
    end

    return deadPlayer
end

-- Spawne ein Prop "models/gag/gaggonkDroide.mdl" neben dem toten Spieler und lasse ihn nach 10 Sekunden auf der selben stelle respawnen, entferne das Prop
function respawnPlayer(caller, deadPlayer)
    
    caller:ChatPrint(prefix .. "Ein Droide wurde gerufen. Bitte warten...")

    if (deadPlayer != nil) then
        local pos = deadPlayer:GetPos()
        local ang = deadPlayer:GetAngles()

        local prop = ents.Create("prop_physics")
        prop:SetModel("models/gag/gaggonkdroid.mdl")
        prop:SetPos(pos)
        prop:SetAngles(ang)
        prop:SetUnFreezable(true)

        prop:AddCallback("PhysicsCollide", function(ent, data)
            -- wenn ein NPC mit dem Prop kollidiert, entferne das Prop
            if (data.HitEntity:IsNPC()) then
                caller:ChatPrint(prefix .. "Der Droide, den du gerufen hast, wurde zerstört.")
                deadPlayer:ChatPrint(prefix .. "Der Droide wurde zerstört. Bitte warte bis ein neuer gerufen wird.")
                prop:Remove()
            end
            if (data.HitEntity:IsPlayer()) then
                caller:ChatPrint(prefix .. "Der Droide, den du gerufen hast, wurde zerstört.")
                deadPlayer:ChatPrint(prefix .. "Der Droide wurde zerstört. Bitte warte bis ein neuer gerufen wird.")
                prop:Remove()
            end
        end)

        prop:Spawn()

        deadPlayer:ChatPrint(prefix .. "Ein Droide wurde für dich gerufen. Bitte warte bis er dich behandelt.")

        timer.Simple(15, function()
        
            if (!IsValid(prop)) then
                prop:Remove()
                return
            end

            if (deadPlayer:Alive()) then
                deadPlayer:ChatPrint(prefix .. "Du bist bereits wieder am Leben.")
                prop:Remove()
                return
            end

            -- Spawne kurz folgende Effekte "pfx4_05~", und spiele einen zap sound ab
            local effectdata = EffectData()
            effectdata:SetOrigin(deadPlayer:GetPos())
            effectdata:SetMagnitude(1)
            effectdata:SetScale(1)
            effectdata:SetRadius(1)
            util.Effect("Sparks", effectdata)
            util.Effect("pfx4_05", effectdata)
            deadPlayer:EmitSound("ambient/energy/zap1.wav", 100, 100)

            -- Spawne den Spieler wieder
            deadPlayer:Spawn()
            deadPlayer:SetHealth(50)
            deadPlayer:SetPos(pos)
            prop:Remove()
        end)
    end
end



function commandHandler(ply, text, plyteam)
    
    if (string.sub(text, 1, 8) == "/aed") then

        if (ply:Alive() == false) then
            ply:ChatPrint(prefix .. "Du kannst dich nicht selbst heilen.")
            return ""
        end
        
        local arzt = false 
        local teams = team.GetAllTeams()
        local users = player.GetAll()

        for k, v in pairs(teams) do
            if (string.sub(v.Name, 1, 17) == "8th Medic Company") then
                for l, w in pairs(users) do
                    if (w:Team() == k) then
                        arzt = true
                    end
                end
            end      
        end

        if (arzt) then
            ply:ChatPrint(prefix .. "Es ist ein Arzt im Dienst.")
        else 
            local deadPlayer = getDeadPlayer(ply)

            if (deadPlayer != nil) then
                if deadPlayer:Alive() then
                    ply:ChatPrint(prefix .. "Der Spieler ist bereits wieder am Leben.")
                    return ""
                end
                if (deadPlayer:GetPos():Distance(ply:GetPos()) > 100) then
                    ply:ChatPrint(prefix .. "Der Spieler ist zu weit weg.")
                    return ""
                end
                if (deadPlayer == ply) then
                    ply:ChatPrint(prefix .. "Du kannst dich nicht selbst heilen.")
                    return ""
                end

                respawnPlayer(ply, deadPlayer)

            else
                ply:ChatPrint(prefix .. "Es ist kein toter Spieler in der Nähe.")
            end

        end

        return ""

    end

end

hook.Add("PlayerSay", "JGetCommand", commandHandler)