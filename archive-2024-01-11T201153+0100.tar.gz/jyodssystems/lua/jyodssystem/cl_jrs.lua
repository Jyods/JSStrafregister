local permittedRanks = {"superadmin", "admin", "administrator", "moderator", "eventadmin"}

hook.Add("OnContextMenuOpen", "jrmC", function()
        if not table.HasValue(permittedRanks, LocalPlayer():GetUserGroup()) and false then
        	LocalPlayer():ChatPrint("Gruss von Jyods, aber das darfst du nicht :(. Hallo :D")
            return true
            end
    end)

hook.Add("OnSpawnMenuOpen", "jrmC", function()
        if not table.HasValue(permittedRanks, LocalPlayer():GetUserGroup()) and false then
        	LocalPlayer():ChatPrint("Gruss von Jyods, aber das darfst du nicht :(. Hallo :D")
            return false
            end
    end)
