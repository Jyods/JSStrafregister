if SERVER then
    -- Printe in die Konsole dass das Addon geladen wurde
    local message = "[Jyods Systems] Addons loaded"
    MsgC(Color(0, 255, 0), message)
    print("\n" .. message)
end
