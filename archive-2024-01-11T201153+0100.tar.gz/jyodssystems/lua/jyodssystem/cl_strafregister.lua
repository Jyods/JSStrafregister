if CLIENT then
    local websiteURL = "https://home-5013261951.app-ionos.space"
    local webFrame = nil

    local function CreateWebFrame()
        webFrame = vgui.Create("DFrame")
        webFrame:SetSize(800, 600)
        webFrame:SetTitle("Web Page")
        webFrame:Center()
        webFrame:MakePopup()

        local webView = vgui.Create("DHTML", webFrame)
        webView:Dock(FILL)
        webView:OpenURL(websiteURL)

        webFrame.OnClose = function()
            webFrame = nil
        end
    end

    concommand.Add("open_website", function()
        if not webFrame then
            CreateWebFrame()
        else
            webFrame:SetVisible(true)
        end
    end)

    concommand.Add("close_website", function()
        if webFrame then
            webFrame:Close()
        end
    end)
end